# Labo Exploration — correction des 8 ponts (22 novembre 2026)

Ce lot conserve **exactement les noms et chemins d’assets existants** et préserve les identifiants, orientations et règles de traversée.

- 4 ponts `wood_rustic` : vertical, horizontal, diagonal_left, diagonal_right.
- 4 ponts `castle` : vertical, horizontal, diagonal_left, diagonal_right.
- Format WebP RGBA lossless 512×512. Les pixels visibles et alpha décodés sont identiques à ceux des 8 uploads fournis.
- Chemins de destination : `assets/exploration/objects/bridges/`.
- **Ne pas ajouter une seconde bibliothèque** ; cette archive est une livraison/transfert, non un pack à servir au jeu.
- Le dossier `v81/` est conservé comme historique (pas de nouvelle copie).

### Intégration dans un clone Git du dépôt

Extraire l’archive, puis lancer depuis le dossier extrait :

```shell
python apply_ponts_nettoyes.py /chemin/vers/laboratoire_dynamique_exploration-
```

Le script remplace les huit images existantes et actualise uniquement leurs huit enregistrements (`sha256`, `bytes`, provenance) dans le manifeste canonique.

Contrôler ensuite :

```shell
python scripts/update-bridge-manifest-v74.py
npm test
git status --short
```

Préserver le processus GitHub : lot dédié, branche, CI, checkpoint puis fusion selon validation.
