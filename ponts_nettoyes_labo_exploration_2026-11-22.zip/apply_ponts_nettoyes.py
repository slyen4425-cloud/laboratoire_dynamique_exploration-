#!/usr/bin/env python3
"""Applique les huit visuels 2.5D corrigés au clone local du Labo Exploration.

Usage: python apply_ponts_nettoyes.py /chemin/vers/laboratoire_dynamique_exploration-
Ce script ne modifie que les huit images existantes et leurs huit enregistrements
SHA/bytes du manifeste canonique. Il ne copie rien vers v81/ (historique).
"""
from pathlib import Path
import hashlib,json,shutil,sys
source=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()
inv=json.loads((source/'inventaire.json').read_text(encoding='utf-8'))
manifest_path=repo/'assets/exploration/objects/bridges/manifest.v1.json'
if not manifest_path.exists():
    raise SystemExit('ERREUR: manifeste inexistant, indique la racine du dépôt Exploration.')
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
assert manifest['schemaVersion']==1 and len(manifest['files'])==32
by_path={entry['path']:entry for entry in manifest['files']}
updates=[]
for item in inv['files']:
    rel=item['asset_path']; dest=repo/rel; src=source/rel
    if not dest.exists() or not src.exists():
        raise SystemExit(f'ERREUR fichier non trouvé : {rel}')
    entry=by_path.get(rel)
    if not entry or entry.get('role')!='bridge-visual' or '_2p5d_' not in rel:
        raise SystemExit('ERREUR manifeste inconnu : '+rel)
    data=src.read_bytes()
    assert data[:4]==b'RIFF' and data[8:12]==b'WEBP' and data[12:16]==b'VP8L'
    assert hashlib.sha256(data).hexdigest()==item['sha256']
    updates.append((src,dest,entry,item))
assert len(updates)==8
for src,dest,entry,item in updates:
    shutil.copyfile(src,dest)
    entry['sha256']=item['sha256']
    entry['bytes']=item['bytes']
    entry['runtimeProfile']='mobile-webp-512x512-lossless-v74'
    entry['sourceFile']='nettoyage manuel fourni le 2026-11-22 : '+item['file']
    entry['sourceSha256']=item['source_sha256']
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('OK : 8 ponts mis à jour dans la bibliothèque canonique, 8 SHA réconciliés.')
print('Anciennes versions préservées via historique Git. v81 non modifié.')
print('À vérifier : python scripts/update-bridge-manifest-v74.py ; npm test')
