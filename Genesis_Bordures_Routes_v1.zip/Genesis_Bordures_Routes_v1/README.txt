GENESIS RPG — LABO EXPLORATION — Bordures routes v1 (prototype)

14 assets uniques : 6 bandes horizontales et 8 sprites de cailloux.
Sources PNG RGBA et dérivés WebP sans perte ; intégrer uniquement les WebP.
Bandes : 512 x 128, côté extérieur en haut, côté route en bas, axe de référence y=64.
Sprites : 128 x 128, pivot centre (64,64). Ajuster échelle et espacement dans le futur éditeur.
Les bandes sont issues de visuels générés, détourées et raccordées par fondu horizontal. Les extrémités sont identiques numériquement mais le raccord visuel en boucle et le rendu en virage restent à valider. Les bordures bois/pierre ont du volume apparent ; éviter les rotations arbitraires sans test 2.5D. Aucun ID canonique attribué. Le manifeste est descriptif, pas un contrat existant. Aucune collision par défaut.
Le moteur de bordures n’est pas encore implémenté. Aucun test en jeu ni modification GitHub.

CONTRÔLES AUTOMATIQUES
bordure_naturelle : dimensions, alpha, WebP OK ; colonnes terminales identiques
bordure_cailloux : dimensions, alpha, WebP OK ; colonnes terminales identiques
bordure_pierre_taillee : dimensions, alpha, WebP OK ; colonnes terminales identiques
bordure_beton : dimensions, alpha, WebP OK ; colonnes terminales identiques
bordure_bois : dimensions, alpha, WebP OK ; colonnes terminales identiques
bordure_neige : dimensions, alpha, WebP OK ; colonnes terminales identiques
caillou_01 : dimensions, alpha, WebP OK
caillou_02 : dimensions, alpha, WebP OK
caillou_03 : dimensions, alpha, WebP OK
caillou_04 : dimensions, alpha, WebP OK
caillou_05 : dimensions, alpha, WebP OK
caillou_06 : dimensions, alpha, WebP OK
caillou_07 : dimensions, alpha, WebP OK
caillou_08 : dimensions, alpha, WebP OK