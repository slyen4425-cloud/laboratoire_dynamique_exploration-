# GENSRPG — 5 textures de sol (22/11/2026)

Pack prêt pour dépôt / validation avant raccord au Labo Exploration.

Référence vérifiée sur `main` : `assets/exploration/materials/forest/surfaces` ;
le manifeste existant `assets/exploration/materials/forest/manifest.v1.json`
indique des surfaces **WebP 128 × 128**, profil `mobile-test-128`.

## Contenu
- `textures_webp_128/` : 5 WebP 128 × 128, optimisés et adoucis aux raccords.
- `sources_png_hd/` : 5 originaux PNG HD (retouche), non destinés à être raccordés comme deuxième autorité.
- `previews/` : aperçu des textures et grilles répétées 3 × 3 pour contrôles.
- `MANIFEST.json` : traçabilité, noms proposés et SHA256.

## Intégration
Ne pas remplacer un asset existant : création de cinq nouvelles variantes.
Intégrer les WebP dans le pack canonique après validation visuelle, enregistrer des identifiants sémantiques uniques via le Material Registry / Asset Adapter existant ; ne pas déduire collision ou rencontres à partir de la texture.
Pour « Haute herbe » : associer la probabilité de rencontre plus élevée à une **famille de terrain configurable**, pas au fichier image.

Aucune modification des anciens chemins/IDs ni fusion automatique n'a été réalisée.
