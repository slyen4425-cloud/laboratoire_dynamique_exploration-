GENSRPG MONSTER CAPTURE — LOT 1 / 6 PERSONNAGES

Pour chaque héros :
- modele_face.png / modele_dos.png : découpes transparentes
- frames/N, NE, E, SE, S, SW, W, NW/00..05.png : 48 fichiers PNG RGBA transparents (128 x 160 px)
- spritesheet_8_directions_6_frames.png : atlas RGBA facultatif pour l'intégrateur (768 x 1280)
- metadata.json : ordre de lecture, pivot (64, 153), FPS et provenance des animations

N/NE/E/SE/S/SW/W/NW = Nord/Nord-est/Est/Sud-est/Sud/Sud-ouest/Ouest/Nord-ouest.

IMPORTANT ET HONNETE : les quatre premières fiches d'origine n'avaient que 4 vues et 3 poses par vue. Les diagonales de ces quatre héros sont des approximations géométriques à partir des vues existantes, et les images de transition sont interpolées : il reste à dessiner de vraies diagonales pour une animation définitive. Les personnages 05 et 06 disposent de 8 directions sources et six phases, toutes extraites. Les visuels doivent être validés en jeu (échelle, direction et fluidité) avant publication.

Les fichiers fournis sont des assets de travail utilisables pour tester Monster Capture. Aucun code du jeu ni fichier GitHub n'a été modifié.
