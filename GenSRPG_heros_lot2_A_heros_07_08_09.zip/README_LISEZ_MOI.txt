GENSRPG MONSTER CAPTURE - LOT 2 / 6 PERSONNAGES

Chaque personnage : modele_face.png, modele_dos.png (PNG RGBA), images unitaires frames/N|NE|E|SE|S|SW|W|NW/00..05.png (128 x 160 pixels, fond transparent), spritesheet facultative, metadata.json (pivot à 64,153).

Les modèles et les sprites proviennent des six fiches originales créées dans cette conversation ; aucune autre variante n’a été substituée. Les huit directions utilisent chacune les six vues sources. Les silhouettes ont été détourées, les petits artefacts isolés ont été nettoyés et les pieds sont alignés. Une validation sur la carte GenSRPG reste nécessaire pour vérifier la fluidité de la marche avant publication.
