# Pack 20 arbres enneigés — Labo Exploration GenSRPG

20 modèles de végétation hivernale extraits de deux planches validées. Chacun est indépendant, fond transparent, cadré et redimensionné en **384 × 384 px**.

## Organisation
- `assets/exploration/objects/trees/*.webp` : 20 sprites runtime, prêts à copier lors du raccord.
- `masters/png/*.png` : 20 versions PNG RGBA à conserver pour modifications ou exports.
- `previews/APERÇU_20_ARBRES_ENNEIGES.jpg` : planche de contrôle des découpes.
- `manifest.snow-trees.v1.json` : identifiants sémantiques, chemins, SHA256, provenance et ordre des planches.
- `SHA256SUMS.txt` : intégrité des fichiers WebP.

## Intégration après dépôt du ZIP
Les 20 images ne sont pas encore déclarées dans le catalogue runtime ni raccordées au World Builder.
Leur intégration doit respecter la charte du laboratoire : 1 lot = 1 branche, tests et checkpoint GREEN.
Ne pas remplacer les arbres existants ou contourner leur manifeste sans validation.

Origine : planche A (10 arbres) et planche B (10 arbres), toutes deux validées par le créateur le 04/11/2026.
