# GenSRPG Labo Exploration — 10 maisons enneigées 2,5D

30 sprites **individualisés et détourés** à partir de la planche visuelle validée.

- 10 géométries de maisons, 3 vues associées par maison : **FACE**, **CÔTÉ**, **DOS**.
- Image de jeu : **384×384 WebP avec canal alpha RGBA**, qualité 82.
- PNG masters sans perte dans `masters/` pour retouches et régénération.
- Sans plaquette, texte, cadrage de planche ou fond coloré dans les sprites.
- Prévisualisation sur damier dans `previews/`, une planche globale et 10 vues détaillées.
- Détourage des zones sombres de murs en conservant les volumes et le pied des maisons.
- Un seul catalogue officiel prévu : `src/objects/object-definition-catalog.js` + `src/assets/world-object-asset-adapter.js`.
- Collisions, portes, empreintes et intérieur restent à renseigner dans les définitions du moteur ; le fichier image n'est **pas** autorité du gameplay.

## Dépôt GitHub

Déposer le ZIP **sans l'extraire** à la racine de `slyen4425-cloud/laboratoire_dynamique_exploration-`.
La phase de raccordement doit être effectuée en branche dédiée : ne jamais ajouter directement des assets au `main` autrement que le ZIP de livraison validé.
Après récupération, copier les 30 WebP dans les chemins prévus du `manifest.snow-houses.v1.json` et enregistrer 10 définitions avec 3 variantes, puis valider par tests/CI/Pages sans perturber les autres lots.

## Note qualité

Source initiale : une planche concept 1672×941, donc détails individuels limités par la résolution d'origine et agrandis pour correspondre aux 384×384 du runtime. Prévisualiser les modèles en contexte World Builder avant toute publication finale. Les 30 vues ne sont pas des rendus haute résolution indépendants.
